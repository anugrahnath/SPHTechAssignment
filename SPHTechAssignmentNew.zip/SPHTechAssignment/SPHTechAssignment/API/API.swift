//
//  API.swift
//  SPHTechAssignment
//
//  Created by ADMIN on 28/01/19.
//  Copyright © 2019 AnugrahNathTiwari. All rights reserved.
//

import UIKit
import Alamofire

class API : NSObject {
    
    // Can't init is singleton
    private override init() { }
    
    // MARK: Shared Instance
    static let shared = API()
    
    
    typealias getCompletion = (Any?) -> Void
    //MARK: Alamofire BaseUrl
    
    
    
    func getAPIIntegrationWithGetMethod(parameters :[String:Any], andUrl url :String, completion: @escaping getCompletion) -> Void {
        
        if CommonFunction.shared.connectedInternetReachable() == false {
            completion(AppConstant.Error.NoInternet)
        } else {
            let URL : String = CommonFunction.shared.createStringURL(parameters, andBaseURL: url)
            print("Call API : " + url)
            
            Alamofire.request(URL, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: AppConstant.Server.kHeader)
                .responseJSON { response in

                    if let json = response.result.value {
                        completion(json as AnyObject)
                    } else {
                         
                        completion(AppConstant.GeneralError.NoDataFound)
                    }
            }
        }
    }
    
    
}

