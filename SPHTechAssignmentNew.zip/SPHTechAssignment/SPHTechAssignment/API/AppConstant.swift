//
//  AppConstant.swift
//  SPHTechAssignment
//
//  Created by ADMIN on 28/01/19.
//  Copyright © 2019 AnugrahNathTiwari. All rights reserved.
//

import Foundation
import UIKit

struct AppConstant{
    
    enum GeneralError{
        case NoDataFound
    }
    enum Error {
         case NoInternet
    }
    
    //MARK: - For All Server Related Keys
    struct Server{
        static let BaseUrl : String = "https://data.gov.sg/api/action/datastore_search"
        static let kHeader = ["Content-Type" : "application/json"]
    }
    
    struct ColorScheme
    {
        static let Pink = UIColor.init(red: 229.0/255.0, green: 94.0/255.0, blue: 124.0/255.0, alpha: 1.0)
        static let Gray = UIColor.init(red: 50.0/255.0, green: 50.0/255.0, blue: 50.0/255.0, alpha: 1.0)
    }

}
