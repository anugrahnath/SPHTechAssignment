//
//  MobileDataUsageController.swift
//  SPHTechAssignment
//
//  Created by ADMIN on 28/01/19.
//  Copyright © 2019 AnugrahNathTiwari. All rights reserved.
//

import UIKit

class MobileDataUsageController: NSObject {

    // Can't init is singleton
    private override init() { }
    
    // MARK: Shared Instance
    static let shared = MobileDataUsageController()
    
    // MARK: Get Order API
    func GetMobileDataUsageAPI(parameter:[String:Any]!, andURL url: String, completion: @escaping (Any?) -> Void) {
        
        API.shared.getAPIIntegrationWithGetMethod(parameters: parameter, andUrl: url) { (resultResponce) in
            
            if resultResponce is AppConstant.GeneralError {
                
                Toast.init(text: "No response from server ! try later").show()
                completion(AppConstant.GeneralError.NoDataFound)
            }
            else if resultResponce is Error{
             
                completion(AppConstant.Error.NoInternet)
                
            }else{
                let responseDict = resultResponce as! NSDictionary
                
                if responseDict.count > 0 {
                    
                    completion(responseDict)
                    
                } else {
                    
                    completion(AppConstant.GeneralError.NoDataFound)
                }
            }
            
        }
    }
    
}
