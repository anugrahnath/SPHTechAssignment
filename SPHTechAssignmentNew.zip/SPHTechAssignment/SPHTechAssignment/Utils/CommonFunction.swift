//
//  CommonFunction.swift
//  SPHTechAssignment
//
//  Created by ADMIN on 28/01/19.
//  Copyright © 2019 AnugrahNathTiwari. All rights reserved.
//

import UIKit
import Alamofire

class CommonFunction: NSObject {

    // Can't init is singleton
    private override init() { }
    
    // MARK: Shared Instance
    static let shared = CommonFunction()
    
    // MARK :- Create string url
    
    func createStringURL(_ parameter : [String:Any]!, andBaseURL url: String!) -> String {
        var countFlag : Int = 0
        
        var urlStr : String = url
        
        for (key, value) in parameter {
            if countFlag == 0 {
                urlStr += "?\(key)=\(value)"
            }else{
                urlStr += "&\(key)=\(value)"
            }
            countFlag += 1
        }
        
        return urlStr
    }
    
    // MARK :- Check reachbility
    func connectedInternetReachable() -> Bool {
        return NetworkReachabilityManager()!.isReachable
    }
    
    // MARK :- Save data in JSON File
    
    class func saveDataToJsonFile(data : NSDictionary, fileName : String) {
        // Get the url of Persons.json in document directory
        guard let documentDirectoryUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return }
        let fileUrl = documentDirectoryUrl.appendingPathComponent("\(fileName).json")
        do {
            let data = try JSONSerialization.data(withJSONObject: data, options: [])
            try data.write(to: fileUrl, options: [])
        } catch {
            print(error)
        }
        
    }
    
    // MARK : Retrieve Data from JSON File
    class func getDataFromJSONFile(fileName : String, compiletionData: @escaping (NSDictionary?) -> Void)
    {
        guard let documentsDirectoryUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return }
        let fileUrl = documentsDirectoryUrl.appendingPathComponent("\(fileName).json")
        DispatchQueue.global(qos: .background).async {
            do {
                let data = try Data(contentsOf: fileUrl, options: [])
                let dictionary = try JSONSerialization.jsonObject(with: data as Data, options: .allowFragments) as? NSDictionary
                compiletionData(dictionary)
            } catch {
                print(error)
            }
        }
    }
    
    // MARK :- Check JSON File Already exist or not in Document Directory
    class func isJSONFileExistInDocumentDirectory(fileName : String) -> (Bool)
    {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as String
        let url = NSURL(fileURLWithPath: path)
        if let pathComponent = url.appendingPathComponent("\(fileName).json") {
            let filePath = pathComponent.path
            let fileManager = FileManager.default
            if fileManager.fileExists(atPath: filePath) {
                print("FILE AVAILABLE")
                return true
            } else {
                print("FILE NOT AVAILABLE")
                return false
            }
        } else {
            print("FILE PATH NOT AVAILABLE")
            return true
        }
    }
    
    // MARK :- Alert view
    func showAlertWith(_ title:String!, message:String!, onVC:UIViewController!) -> Void {
            let alertC = UIAlertController.init(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
            let okAction = UIAlertAction.init(title: "OK", style: UIAlertAction.Style.cancel, handler: nil)
        
            alertC.addAction(okAction)
        
            onVC.present(alertC, animated: true, completion: nil)
        }
}
