//
//  MobileDataUsageTVC.swift
//  SPHTechAssignment
//
//  Created by ADMIN on 28/01/19.
//  Copyright © 2019 AnugrahNathTiwari. All rights reserved.
//

import UIKit

class MobileDataUsageTVC: UITableViewCell {

    @IBOutlet weak var uiLabelQuater: UILabel!
    
    @IBOutlet weak var uiLabelUsageData: UILabel!
    
    @IBOutlet weak var uiImageViewFlag: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
