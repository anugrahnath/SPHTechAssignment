//
//  MobileDataTotalUsageTVC.swift
//  SPHTechAssignment
//
//  Created by ADMIN on 28/01/19.
//  Copyright © 2019 AnugrahNathTiwari. All rights reserved.
//

import UIKit

class MobileDataTotalUsageTVC: UITableViewCell {

    @IBOutlet weak var uiLabelQuaterTC: UILabel!
    
    @IBOutlet weak var uiLabelMobileUsageDataTC: UILabel!
    @IBOutlet weak var uiImageViewDownTC: UIImageView!
    @IBOutlet weak var uiLabelTotalMobileDataUsage: UILabel!
    
    @IBOutlet weak var uiLabelText: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
