//
//  MobileDataUsageVC.swift
//  SPHTechAssignment
//
//  Created by ADMIN on 28/01/19.
//  Copyright © 2019 AnugrahNathTiwari. All rights reserved.
//

import UIKit
import NVActivityIndicatorView


class MobileDataUsageVC: UIViewController, UITableViewDataSource, UITableViewDelegate,NVActivityIndicatorViewable {
    
    var reusableMobileDataUsageCellIdentifier : String = "MobileDataUsageCell"
    var reusableMobileDataTotalUsageCellIdentifier : String = "MobileDataTotalUsageCell"
    let fileName : String = "MobileDataUsage"
    
    var mobileDataUsageResultModel : MobileDataUsageResultModel?
    var mobileDataUsageRecordsModel : MobileDataUsageRecordsModel?
    var mobileDataUsageRecordsModelData = [MobileDataUsageRecordsModel]()
    
    var yearArray : [String] = [String]()
    var dataArray : [Float] = [Float]()
    var mobileDataUsageArray : [Float] = [Float]()
    
    var cellHeight : Int = 150
    
    
    @IBOutlet weak var uiTableView: UITableView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        if CommonFunction.shared.connectedInternetReachable() {
            self.getServiceData()
        }else{
            if CommonFunction.isJSONFileExistInDocumentDirectory(fileName: fileName){
                self.GetMobileUasgeDataFromJSONFile(fileName: fileName)
                CommonFunction.shared.showAlertWith("Ooops!", message: "No Internet Connection", onVC: self)
            }
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mobileDataUsageRecordsModelData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell:UITableViewCell!
        
        mobileDataUsageRecordsModel = mobileDataUsageRecordsModelData[indexPath.row]
        
        let volumeOfMobileData : String = (mobileDataUsageRecordsModel?.volumeOfMobileData)!
        let quater : String = (mobileDataUsageRecordsModel?.quarter)!
        var quaterArray = quater.components(separatedBy: "-")
        let year = quaterArray[0]
        
        if yearArray[indexPath.row + 1] == year {
            
            if indexPath.row == mobileDataUsageRecordsModelData.count-1{
                mobileDataUsageArray.append(Float(volumeOfMobileData)!)
                let innerTotalCell : MobileDataTotalUsageTVC = tableView.dequeueReusableCell(withIdentifier: self.reusableMobileDataTotalUsageCellIdentifier, for: indexPath) as! MobileDataTotalUsageTVC
                
                innerTotalCell.uiLabelQuaterTC.text = mobileDataUsageRecordsModel?.quarter
                innerTotalCell.uiLabelMobileUsageDataTC.text = mobileDataUsageRecordsModel?.volumeOfMobileData
                innerTotalCell.uiLabelText.text = ("Total Data Usage in \(year) : ")
                innerTotalCell.uiLabelTotalMobileDataUsage.text = "\(mobileDataUsageArray.reduce(0, +))"
                
                
                        if Float(volumeOfMobileData)! < dataArray[indexPath.row - 1]  {
                            innerTotalCell.uiImageViewDownTC.isHidden = false
                        }
                        else{
                            innerTotalCell.uiImageViewDownTC.isHidden = true
                        }
                mobileDataUsageArray.removeAll()
                cell = innerTotalCell
                cellHeight = 80
                tableView.beginUpdates()
                tableView.endUpdates()
            }else{
             mobileDataUsageArray.append(Float(volumeOfMobileData)!)
                
            let innerCell : MobileDataUsageTVC = tableView.dequeueReusableCell(withIdentifier: self.reusableMobileDataUsageCellIdentifier, for: indexPath) as! MobileDataUsageTVC
            
            innerCell.uiLabelQuater.text = mobileDataUsageRecordsModel?.quarter
            innerCell.uiLabelUsageData.text = mobileDataUsageRecordsModel?.volumeOfMobileData
             
                if indexPath.row > 0{
                if Float(volumeOfMobileData)! < dataArray[indexPath.row - 1]  {
                    innerCell.uiImageViewFlag.isHidden = false
                }
                else{
                    innerCell.uiImageViewFlag.isHidden = true
                }
                }
            cell = innerCell
            cellHeight = 40
            tableView.beginUpdates()
            tableView.endUpdates()
            }
            
        }else{
            mobileDataUsageArray.append(Float(volumeOfMobileData)!)
            let innerTotalCell : MobileDataTotalUsageTVC = tableView.dequeueReusableCell(withIdentifier: self.reusableMobileDataTotalUsageCellIdentifier, for: indexPath) as! MobileDataTotalUsageTVC
            
            innerTotalCell.uiLabelQuaterTC.text = mobileDataUsageRecordsModel?.quarter
            innerTotalCell.uiLabelMobileUsageDataTC.text = mobileDataUsageRecordsModel?.volumeOfMobileData
            innerTotalCell.uiLabelText.text = ("Total Data Usage in \(year) : ")
            innerTotalCell.uiLabelTotalMobileDataUsage.text = "\(mobileDataUsageArray.reduce(0, +))"
            
            if Float(volumeOfMobileData)! < dataArray[indexPath.row - 1]  {
                innerTotalCell.uiImageViewDownTC.isHidden = false
            }
                else{
                    innerTotalCell.uiImageViewDownTC.isHidden = true
                }
            mobileDataUsageArray.removeAll()
            
            cell = innerTotalCell
            cellHeight = 80
            tableView.beginUpdates()
            tableView.endUpdates()
            
            }
        
        return cell
    }
  
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        return CGFloat(cellHeight)
    }
    

}
extension MobileDataUsageVC{
    
    func getServiceData() {
        
        let size = CGSize(width: 40, height: 40)
        self.startAnimating(size, message: "Loading Mobile Data...", type: NVActivityIndicatorType(rawValue: 29)!, color: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), fadeInAnimation: nil)
        
            let mobileDataUsageController = MobileDataUsageController.shared
            
            var param : [String : Any] = [String : Any]()
            param = [
                "resource_id" : "a807b7ab-6cad-4aa6-87d0-e283a7353a0f"
            ]
            
            let url : String = AppConstant.Server.BaseUrl
            mobileDataUsageController.GetMobileDataUsageAPI(parameter: param, andURL: url, completion: { [weak self]
                (response) in
                
                guard let strongSelf = self else {
                    return
                }
                if response is AppConstant.GeneralError{
                    Toast.init(text: "No response from server ! try later").show()
                }
                else if response is Error{
                    CommonFunction.shared.showAlertWith("Ooops!", message: "No Internet Connection", onVC: self)
                }
                else{
                    let responseDict = response as? NSDictionary
                    if responseDict != nil{
                        let isSuccessful = responseDict?["success"] as? Bool
                        if isSuccessful! {
                            CommonFunction.saveDataToJsonFile(data: (responseDict)!, fileName: (self?.fileName)!)
                            let resultDict = responseDict?["result"] as? NSDictionary
                            self!.mobileDataUsageResultModel = MobileDataUsageResultModel.init(fromDictionary: resultDict as! [String : Any])
                            
                            self!.mobileDataUsageRecordsModelData = (self!.mobileDataUsageResultModel?.records)!
                            
                            var year : String = ""
                            var volumeOfMobileData : String = ""
                            
                            for index in 0...self!.mobileDataUsageRecordsModelData.count - 1 {
                                self!.mobileDataUsageRecordsModel = self!.mobileDataUsageRecordsModelData[index]
                                let quater : String = (self!.mobileDataUsageRecordsModel?.quarter)!
                                volumeOfMobileData = (self!.mobileDataUsageRecordsModel?.volumeOfMobileData)!
                                var quaterArray = quater.components(separatedBy: "-")
                                year = quaterArray[0]
                                self!.yearArray.append(year)
                                self!.dataArray.append(Float(volumeOfMobileData)!)
                            }
                            self!.yearArray.append(year)
                            self!.dataArray.append(Float(volumeOfMobileData)!)
                            self!.uiTableView.reloadData()
                        }
                        else{
                                Toast.init(text: "No response from server ! try later").show()
                            }
                        }
                }
            })
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1) {
            self.stopAnimating(nil)
        }
    }
    
    func GetMobileUasgeDataFromJSONFile(fileName : String) {
        
        guard let documentsDirectoryUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return }
        let fileUrl = documentsDirectoryUrl.appendingPathComponent("\(fileName).json")
        
        do {
            let data = try Data(contentsOf: fileUrl, options: [])
            let dictionary = try JSONSerialization.jsonObject(with: data as Data, options: .allowFragments) as? NSDictionary
            let resultDict = dictionary!["result"] as? NSDictionary
            
            self.mobileDataUsageResultModel = MobileDataUsageResultModel.init(fromDictionary: resultDict as! [String : Any])
                self.mobileDataUsageRecordsModelData = (self.mobileDataUsageResultModel?.records)!
            
                var year : String = ""
                var volumeOfMobileData : String = ""
            
                for index in 0...self.mobileDataUsageRecordsModelData.count - 1 {
                    self.mobileDataUsageRecordsModel = self.mobileDataUsageRecordsModelData[index]
                    let quater : String = (self.mobileDataUsageRecordsModel?.quarter)!
                    volumeOfMobileData = (mobileDataUsageRecordsModel?.volumeOfMobileData)!
                    var quaterArray = quater.components(separatedBy: "-")
                    year = quaterArray[0]
                    self.yearArray.append(year)
                    dataArray.append(Float(volumeOfMobileData)!)
                    
                }
                self.yearArray.append(year)
                self.dataArray.append(Float(volumeOfMobileData)!)
                self.uiTableView.reloadData()
               
            } catch {
                print(error)
            }
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1) {
            self.stopAnimating(nil)
        }
    }
}
