//
//  MobileDataUsageLinkModel.swift
//  SPHTechAssignment
//
//  Created by ADMIN on 28/01/19.
//  Copyright © 2019 AnugrahNathTiwari. All rights reserved.
//

import UIKit

class MobileDataUsageLinkModel: NSObject, NSCoding{
    
    var next : String!
    var start : String!
    
    
    /**
     * Instantiate the instance using the passed dictionary values to set the properties values
     */
    init(fromDictionary dictionary: [String:Any]){
        next = dictionary["next"] as? String
        start = dictionary["start"] as? String
    }
    
    /**
     * Returns all the available property values in the form of [String:Any] object where the key is the approperiate json key and the value is the value of the corresponding property
     */
    func toDictionary() -> [String:Any]
    {
        var dictionary = [String:Any]()
        if next != nil{
            dictionary["next"] = next
        }
        if start != nil{
            dictionary["start"] = start
        }
        return dictionary
    }
    
    /**
     * NSCoding required initializer.
     * Fills the data from the passed decoder
     */
    @objc required init(coder aDecoder: NSCoder)
    {
        next = aDecoder.decodeObject(forKey: "next") as? String
        start = aDecoder.decodeObject(forKey: "start") as? String
    }
    
    /**
     * NSCoding required method.
     * Encodes mode properties into the decoder
     */
    @objc func encode(with aCoder: NSCoder)
    {
        if next != nil{
            aCoder.encode(next, forKey: "next")
        }
        if start != nil{
            aCoder.encode(start, forKey: "start")
        }
    }
}
