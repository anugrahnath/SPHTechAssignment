//
//  MobileDataUsageResultModel.swift
//  SPHTechAssignment
//
//  Created by ADMIN on 28/01/19.
//  Copyright © 2019 AnugrahNathTiwari. All rights reserved.
//

import UIKit

class MobileDataUsageResultModel: NSObject, NSCoding{
    
    var links : MobileDataUsageLinkModel!
    var fields : [MobileDataUsageFieldsModel]!
    var limit : Int!
    var records : [MobileDataUsageRecordsModel]!
    var resourceId : String!
    var total : Int!
    
    
    /**
     * Instantiate the instance using the passed dictionary values to set the properties values
     */
    init(fromDictionary dictionary: [String:Any]){
        limit = dictionary["limit"] as? Int
        resourceId = dictionary["resource_id"] as? String
        total = dictionary["total"] as? Int
        if let linksData = dictionary["_links"] as? [String:Any]{
            links = MobileDataUsageLinkModel(fromDictionary: linksData)
        }
        fields = [MobileDataUsageFieldsModel]()
        if let fieldsArray = dictionary["fields"] as? [[String:Any]]{
            for dic in fieldsArray{
                let value = MobileDataUsageFieldsModel(fromDictionary: dic)
                fields.append(value)
            }
        }
        records = [MobileDataUsageRecordsModel]()
        if let recordsArray = dictionary["records"] as? [[String:Any]]{
            for dic in recordsArray{
                let value = MobileDataUsageRecordsModel(fromDictionary: dic)
                records.append(value)
            }
        }
    }
    
    /**
     * Returns all the available property values in the form of [String:Any] object where the key is the approperiate json key and the value is the value of the corresponding property
     */
    func toDictionary() -> [String:Any]
    {
        var dictionary = [String:Any]()
        if limit != nil{
            dictionary["limit"] = limit
        }
        if resourceId != nil{
            dictionary["resource_id"] = resourceId
        }
        if total != nil{
            dictionary["total"] = total
        }
        if links != nil{
            dictionary["links"] = links.toDictionary()
        }
        if fields != nil{
            var dictionaryElements = [[String:Any]]()
            for fieldsElement in fields {
                dictionaryElements.append(fieldsElement.toDictionary())
            }
            dictionary["fields"] = dictionaryElements
        }
        if records != nil{
            var dictionaryElements = [[String:Any]]()
            for recordsElement in records {
                dictionaryElements.append(recordsElement.toDictionary())
            }
            dictionary["records"] = dictionaryElements
        }
        return dictionary
    }
    
    /**
     * NSCoding required initializer.
     * Fills the data from the passed decoder
     */
    @objc required init(coder aDecoder: NSCoder)
    {
        links = aDecoder.decodeObject(forKey: "_links") as? MobileDataUsageLinkModel
        fields = aDecoder.decodeObject(forKey: "fields") as? [MobileDataUsageFieldsModel]
        limit = aDecoder.decodeObject(forKey: "limit") as? Int
        records = aDecoder.decodeObject(forKey: "records") as? [MobileDataUsageRecordsModel]
        resourceId = aDecoder.decodeObject(forKey: "resource_id") as? String
        total = aDecoder.decodeObject(forKey: "total") as? Int
    }
    
    /**
     * NSCoding required method.
     * Encodes mode properties into the decoder
     */
    @objc func encode(with aCoder: NSCoder)
    {
        if links != nil{
            aCoder.encode(links, forKey: "_links")
        }
        if fields != nil{
            aCoder.encode(fields, forKey: "fields")
        }
        if limit != nil{
            aCoder.encode(limit, forKey: "limit")
        }
        if records != nil{
            aCoder.encode(records, forKey: "records")
        }
        if resourceId != nil{
            aCoder.encode(resourceId, forKey: "resource_id")
        }
        if total != nil{
            aCoder.encode(total, forKey: "total")
        }
    }
}

